package com.porag.edittext;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // creating object of my application

    EditText editText1,editText2;
    TextView textView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // connecting this objects to java

        editText1 = findViewById(R.id.editTEXT1);
        editText2 = findViewById(R.id.editTEXT2);
        textView = findViewById(R.id.textView);
        button = findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // get information form the object

                String string1 = editText1.getText().toString();
                String string2 = editText2.getText().toString();

                // set information from the text


                if (string1.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter your name", Toast.LENGTH_SHORT).show();
                } else if (string2.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter  your number ", Toast.LENGTH_SHORT).show();
                } else {
                    textView.setText("your text is:  " + string1 + "and other is: " + string2 + ".");
                }

            }
        });


    }
}